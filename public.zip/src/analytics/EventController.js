import { logEvent, setUserProperties } from "@firebase/analytics";
import { useLocation } from "react-router";
import { analytics } from "../services/firebase";

export const ScreenPath = () => {
  const location = useLocation();
  const currentPath = location.pathname;
  // const userId = localStorage.getItem("email"); // Use a custom user ID instead of email

  
    logEvent(analytics, "Screen visit tracker", {
      pathName: currentPath == "/" ? "Login" : currentPath.replaceAll("/", " "),
      userName: localStorage.getItem("name"),
    });
  

  return null;
};

export const setUserProperty = async () =>{
  const client_name = localStorage.getItem('client_name')
  // console.error(client_name,"cllllll")
  if(client_name)
  setUserProperties(analytics, { client_name });
}

export const trackDownload = async (name,title,type)=>{
  const report_download_platform = localStorage.getItem('platform_type').replace(/"/g, '').substring(1)
  const report_name = name
  const report_title = title
  const report_type = type
  const report_ext = name.split('.')[1]
//  console.error({report_download_platform,report_name,report_type,report_ext,report_title},"analytics")
 logEvent(analytics,"report_download",{
  report_download_platform,
  report_title,
  report_name,
  report_type,
  report_ext
 })
}

export const trackCard = async (name)=>{
  //  console.error(name,"cardddd")
   logEvent(analytics,"metric_card_click",{
    card_name : name
   })
}

export const trackCampaignManagerTabs = (tab)=>{ 
  // console.error(tab,"tabbbb")
  const tab_platform = localStorage.getItem('platform_type').replace(/"/g, '').substring(1)
  const tab_name = tab
   logEvent(analytics,"CM_tab_view",{
   tab_platform,
   tab_name
   })
  
}

export const trackCreateCampaignClick = ()=>{
  const platform = localStorage.getItem('platform_type').replace(/"/g, '').substring(1)
   logEvent(analytics,"create_campaign_clicked",{
   button_name: "Create",
   platform
  })
}

export const trackSelectedCampaignType = (selected_campaign_type)=>{
  const platform = localStorage.getItem('platform_type').replace(/"/g, '').substring(1)
   logEvent(analytics,"selected_campaign_type",{
   selected_campaign_type,
   platform
   })
}

export const trackCampaignCreationSteps = (step_name)=>{
  const platform = localStorage.getItem('platform_type').replace(/"/g, '').substring(1)
  logEvent(analytics,"creation_steps",{
  step_name,
  platform
  })
}

export const trackCampaignCreation = (message)=>{
  logEvent(analytics,"campaign_created",{
    message,
  })
}

