/* eslint-disable */
import {
  BrowserRouter as Router,
  Switch,
  // Redirect,
  // Route,
} from "react-router-dom";
// import MainLayout from "./component/common-components/main-layout";
import _ from "lodash";
import React, { useState, useEffect } from "react";
import Helpdesk from '../src/component/helpdesk/Helpdesk'
import { PrivateRoute } from "./routes/PrivateRoute";
import { RestrictedRoute } from "./routes/RestrictedRoute";
import availableRoutes from "./routes/availableRoutes";
import { AuthProvider } from "./context/authContext";
import { APPLICATION_ROUTES } from "./utils/constants";
// import { createBrowserHistory } from "history";
// import { useHistory } from "react-router-dom";
import { useSelector } from "react-redux";

import StandardErrorBoundary from "./services/errorBoundary";
import { ScreenPath, setUserProperty } from "./analytics/EventController";
import config from "../src/appConfig.json";
import { EbuxProvider } from "./component/Ebux/Context/EbuxProvider";

function App() {
  // const [isLoggedIn, setLoggedIn] = useState(false);
  const user_info = useSelector((state) => state.AuthReducer);
  // const history = createBrowserHistory();
  // const location = useLocation();
  // const historyChange = () => {
  //   if (window.location.pathname !== history.location.pathname) {
  //     history.push(window.location.pathname);
  //   }
  // };

  // useEffect(() => {
  //   // history.listen(historyChange)
  // }, [historyChange]);
  // console.log("history>>>>>>>>>>>>.", history);

  // useEffect(() => {
  //   dispatch(checkIsLoggedIn());
  // }, [window.location.pathname]);

  useEffect(() => {
    // const token = localStorage.getItem("token");
    // // console.log(token, "...............");
    // if (token) {
    //   setLoggedIn(true);
    // }
    setUserProperty(); //set client as user property for analytics.
    // Google Analytics 4 (GA4) tag script
    const script = document.createElement("script");
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${config.measurmentID}`;
    document.head.appendChild(script);
    script.onload = () => {
      window.dataLayer = window.dataLayer || [];
      function gtag() {
        dataLayer.push(arguments);
      }
      gtag("js", new Date());
      gtag("config", `${config.measurmentID}`);
    };
    // Cleanup function to remove the script on component unmount
    return () => {
      document.head.removeChild(script);
    };
    // console.log(isLoggedIn, token, "<<<<<<<<<,, logged in ");
  }, []);
  return (
    <>
      <Router>
        {/* ScreenPath --- > to track page navigation in firebase */}
        {/* <ScreenPath />  */}
        <AuthProvider>
        <EbuxProvider>
          {/* <StandardErrorBoundary> */}
          <React.Suspense
            fallback={
              <div className="w-full h-screen grid justify-items-stretch align-middle">
                <img
                  className="w-1/6 justify-self-center inline-block align-middle mt-48 "
                  src="/assets/images/egenie.gif"
                  alt="loader"
                />
              </div>
            }
          >
            <Switch>
              {availableRoutes.map((route) =>
                route.isPrivate ? (
                  <PrivateRoute
                    key={route.routePath}
                    exact
                    user_info={user_info}
                    path={route.routePath}
                    roles={route.accessRoles}
                    component={route.component}
                    platform={_.trimStart(route?.sidebar, "/")}
                  />
                ) : (
                  <RestrictedRoute
                    key={route.routePath}
                    exact
                    path={route.routePath}
                    user_info={user_info}
                    component={route.component}
                    visibleAfterLogin={route.visibleAfterLogin}
                  />
                )
              )}
            </Switch>
          </React.Suspense>
          {/* </StandardErrorBoundary> */}
          </EbuxProvider>
        </AuthProvider>
        {/* <Helpdesk /> */}
      </Router>
    </>
  );
}

export default App;
